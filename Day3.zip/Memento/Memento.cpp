#include <iostream>
#include <ctime>
#include <string>
#include <vector>
using namespace std;

class Memento {
public:
	virtual string getState() const = 0;
	virtual string getDate() const = 0;
};
class ConcreteMemento : public Memento {
private:
	string state;
	string date;
public:
	ConcreteMemento(string state) :state(state) {
		auto now = time(0);
		char buffer[30];
		ctime_s(buffer, 30, &now);
		date = buffer;
		cout << "Initialization at " << date << endl;
	}
	inline string getState() const override { return state; }
	inline string getDate() const override { return date; }
};
class Serializable {
public:
	virtual Memento* save() = 0;
	virtual void restore(Memento* m) = 0;
};
class Originator : public Serializable {
private:
	string state;
public:
	Originator(string state) : state(state) {
		cout << "Initial state = " << state << endl;
	}
	inline void setState(string state) { this->state = state; }

	Memento* save() { return new ConcreteMemento(state); }
	void restore(Memento* m) {
		state = m->getState();
		cout << "State restored from memento (" << m->getDate() << ") = " << state << endl;
	}

	friend ostream& operator<<(ostream& s, const Originator& o) {
		return s << "Current state: " << o.state << endl;
	}
};

class SerializationContext {
private:
	vector<Memento*> mementos;
	Serializable* originator;
public:
	SerializationContext(Serializable* o) : originator(o) {}
	void backup() {
		mementos.emplace_back(originator->save());
	}
	void restore() {
		if (!mementos.empty()) {
			auto memento = mementos.back();
			mementos.pop_back();
			originator->restore(memento);
		}
		else
			cout << "No previous saved state" << endl;
	}
};
int main()
{
	auto o = new Originator("Stato iniziale");

	auto c = new SerializationContext(o);
	c->backup();
	o->setState("Nuovo stato");
	cout << *o << endl;
	c->backup();
	o->setState("Altro stato");
	cout << *o << endl;
	c->restore();
	cout << "Stato ripristinato -> " << *o << endl;
	c->restore();
	cout << "Stato ripristinato -> " << *o << endl;
}
