#include <iostream>
#include <string>
#include <functional>
#include <vector>
using namespace std;
bool swapIfLess(int a, int b) { return a < b; }
bool swapIfGreater(int a, int b) { return a > b; }
class Sorter {
protected:
	virtual bool checkIfSwap(int, int) = 0;
public:
	void sort(int* a, int size) {
		for (int i = 0; i < size - 1; ++i)
			for (int j = i + 1; j < size; ++j)
				//if (a[i] > a[j]) {
				if (checkIfSwap(a[i], a[j])) {
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
	void sortByMethod(int* a, int size, bool (*f)(int, int)) {
		for (int i = 0; i < size - 1; ++i)
			for (int j = i + 1; j < size; ++j)
				//if (a[i] > a[j]) {
				if (f(a[i], a[j])) {
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
	void sortByFunctional(int* a, int size, function<bool(int, int)> f) {
		for (int i = 0; i < size - 1; ++i)
			for (int j = i + 1; j < size; ++j)
				//if (a[i] > a[j]) {
				if (f(a[i], a[j])) {
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
	void sortAsc(int* a, int size) {
		for (int i = 0; i < size - 1; ++i)
			for (int j = i + 1; j < size; ++j)
				//if (a[i] > a[j]) {
				if (swapIfGreater(a[i], a[j])) {
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
	void sortDesc(int* a, int size) {
		for (int i = 0; i < size - 1; ++i)
			for (int j = i + 1; j < size; ++j)
				if (swapIfLess(a[i], a[j])) {
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
};

class DescSorter : public Sorter {
protected:
	bool checkIfSwap(int a, int b) override { return a < b; }
};
class AscSorter : public Sorter {
protected:
	bool checkIfSwap(int a, int b) override { return a > b; }
};

void print(int* a, int size, string message) {
	cout << message << endl;
	while (size--)
		cout << *(a++) << endl;
}
int main()
{
	int numbers[]{ 324,234,764,4768,589,23465,2314,67,657980 };
	print(numbers, 9, "Array iniziale");

	DescSorter s;
	s.sortAsc(numbers, 9);
	print(numbers, 9, "Array ordinato in senso crescente");
	s.sortDesc(numbers, 9);
	print(numbers, 9, "Array ordinato in senso decrescente");
	s.sortByMethod(numbers, 9, swapIfGreater);
	print(numbers, 9, "Array ordinato in senso crescente con il passaggio di un metodo");
	s.sortByMethod(numbers, 9, swapIfLess);
	print(numbers, 9, "Array ordinato in senso decrescente con il passaggio di un metodo");

	s.sort(numbers, 9);
	print(numbers, 9, "Array ordinato con DescSorter");
	AscSorter asc;
	asc.sort(numbers, 9);
	print(numbers, 9, "Array ordinato con AscSorter");
	bool ascSort = false;
	asc.sortByFunctional(numbers, 9,
		[=](int x, int  y) { return ascSort ? x > y : x < y; });
	print(numbers, 9, "Array ordinato con notazione funzionale (lambda)");
	vector<int> v{ 32,25346,53468,21345,4678 };
	int from = 3000;
	int to = 6000;
	auto f = find_if(v.begin(), v.end(),
		[from, to](int x) {return x >= from && x <= to; });
	cout << *f << endl;
}
