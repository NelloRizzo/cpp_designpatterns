#include <iostream>
#include <string>
using namespace std;

class Strategy {
	string name;
public:
	inline string getName()const { return name; }
	Strategy(string n) : name{ n } {}
	virtual float execute(float a, float b) = 0;
};
class OperationExecutor {
	Strategy* strategy;
public:
	OperationExecutor(Strategy* s) :strategy(s) {}
	void executeOperation(float x, float y) {
		cout << "Strategy(" << strategy->getName() << ") = " <<
			strategy->execute(x, y) << endl;
	}
};
class AdditionStrategy : public Strategy {
public:
	AdditionStrategy() :Strategy("addition") {}
	inline float execute(float a, float b) { return a + b; }
};
class MultiplyStrategy : public Strategy {
public:
	MultiplyStrategy() :Strategy("multiply") {}
	inline float execute(float a, float b) { return a * b; }
};
int main()
{
	auto ex = new OperationExecutor(new AdditionStrategy());
	ex->executeOperation(5, 10);
}
