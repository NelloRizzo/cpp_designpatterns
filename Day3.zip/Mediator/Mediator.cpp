#include <iostream>
#include <string>
using namespace std;

class Component;

class Mediator {
public:
	virtual void notify(Component* sender, string event) = 0;
};

class Component {
protected:
	Mediator* mediator;
public:
	Component() : Component(nullptr) {}
	Component(Mediator* mediator) :mediator(mediator) {}
	inline void setMediator(Mediator* mediator) { this->mediator = mediator; }
};

class Button : public Component {
private:
	bool enabled;
public:
	Button() :Button(nullptr) {}
	Button(Mediator* mediator) : Component(mediator), enabled(false) {}
	void setEnabled(bool enabled) { this->enabled = enabled; }
	void click() {
		if (enabled)
			mediator->notify(this, "Button click");
		else
			cout << "Button is disabled then don't fires click event" << endl;
	}
};

class TextBox : public Component {
private:
	string content;
	void textChanged() {
		mediator->notify(this, "Text changed");
	}
public:
	TextBox() :TextBox("") {}
	TextBox(string content) :TextBox(content, nullptr) {}
	TextBox(string content, Mediator* mediator) :Component(mediator), content(content) {
		if (content.length() > 0) textChanged();
	}

	inline string getContent() { return content; }
	inline void setContent(string content) {
		this->content = content;
		textChanged();
	}
};

class Window :public Mediator {
private:
	TextBox* textBox;
	Button* button;

	void handleButtonClick() {
		cout << "Click sul button" << endl;
	}
	void handleTextChanged() {
		cout << "Text changed" << endl;
		button->setEnabled(textBox->getContent().length() != 0);
	}
public:
	Window() :Window(nullptr, nullptr) {}
	Window(TextBox* t, Button* b) :textBox{ t }, button{ b } {
		textBox->setMediator(this);
		button->setMediator(this);
	}

	virtual void notify(Component* sender, string event) {
		if (sender == button)
			handleButtonClick();
		if (sender == textBox)
			handleTextChanged();
	}
};
int main()
{
	auto b = new Button();
	auto t = new TextBox();

	auto w = new Window(t, b);
	cout << "Contenuto della textbox: " << t->getContent() << " - Clicco sul button" << endl;
	b->click();
	t->setContent("Prova");
	cout << "Contenuto della textbox: " << t->getContent() << " - Clicco sul button" << endl;
	b->click();

}
