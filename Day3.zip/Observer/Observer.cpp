#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Observer {
public:
	virtual void update(bool) = 0;
};

class Switch {
	string name;
	bool state;
	vector<Observer*> observers;
	void notify() {
		for (auto i = observers.begin(); i != observers.end(); i++)
			(*i)->update(state);
	}
public:
	Switch(string name) :name(name), state(false) {}
	void addListener(Observer* o) { observers.emplace_back(o); }
	void removeListener(Observer* o) {
		observers.erase(
			find_if(observers.begin(), observers.end(),
				[o](auto obs) { return obs == o; }));
	}
	void press() {
		state = !state;
		cout << "Switch " << name << " pressed - state: " << state << endl;
		notify();
	}
	friend ostream& operator<<(ostream& s, const Switch& sw) {
		return s << sw.name;
	}
};
class Lamp {
private:
	string name;
public:
	Lamp(string name) :name(name) {}
	friend ostream& operator<<(ostream& s, const Lamp& l) {
		return s << l.name;
	}
};

class SwitchObserver :public Observer {
private:
	Lamp* l;
	Switch* s;
	void update(bool state) override {
		cout << "Lamp " << *l << " received notify from switch " << *s << " state is " << state << endl;
	}
public:
	SwitchObserver(Lamp* l, Switch* s) :l(l), s(s) {	}
};
void system() {
	auto s = new Switch("corridoio");
	auto lcorridoio = new Lamp("corridoio");
	auto lcucina = new Lamp("cucina");

	auto o1 = new SwitchObserver(lcorridoio, s);
	s->addListener(o1);
	auto o2 = new SwitchObserver(lcucina, s);
	s->addListener(o2);
	s->press();
	s->removeListener(o1);
	s->press();
}
int main()
{
	system();
}