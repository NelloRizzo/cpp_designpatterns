/*
* Un'automobile inizialmente spenta pu� essere messa in moto,
* dopo di che potr� camminare, fermarsi, spegnere il motore.
* 
* Essa avr� diversi stati possibili:
* 
* (1) Spenta            -> (2)
* (2) Motore acceso     -> (1), (3)
* (3) In moto           -> (4)
* (4) Fermata           -> (3), (1)
*/
#include <iostream>
#include <vector>
using namespace std;

class Automobile;

class State {
protected:
    Automobile* automobile;
public:
    State(Automobile* a) :automobile{ a } {}
    virtual void handle() = 0;
};

class Off : public State {
public:
    Off(Automobile* a) :State(a) {}
    void handle() override {
        cout << "L'automobile � spenta" << endl;
    }
};
class EngineOn : public State {
public:
    EngineOn(Automobile* a) : State(a) {}
    void handle() override {
        cout << "Il motore � acceso" << endl;
    }
};
class Running : public State {
public:
    Running(Automobile* a) : State(a) {}
    void handle() override {
        cout << "La macchina si muove" << endl;
    }
};
class Staying : public State {
public:
    Staying(Automobile *a):State(a){}
    void handle() override {
        cout << "La macchina � ferma col motore acceso" << endl;
    }
};

class Automobile {
    State* state;
public:
    inline State* getState() { return state; }
    Automobile() : state(new Off(this)) {}

    void turnOff() { state = new Off(this); }
    void turnOn() { state = new EngineOn(this); }
    void run() { state = new Running(this); }
    void stop() { state = new Staying(this); }

    void operate() {
        getState()->handle();
    }

};
int main()
{
    Automobile* a = new Automobile();
    a->turnOn();
    a->operate();
    a->run();
    a->operate();
}
