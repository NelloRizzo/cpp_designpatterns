#include <iostream>
#include <vector>
#include <sstream>
using namespace std;

class Element;
class Circle;
class Rectangle;
class Visitor {
public:
	virtual void visitCircle(Circle*) = 0;
	virtual void visitRectangle(Rectangle*) = 0;
};

class Element {
public:
	virtual void accept(Visitor*) = 0;
};

class Shape : public Element {
public:
	virtual void accept(Visitor* v) = 0;
};

class Circle : public Shape {
private:
	float center_x;
	float center_y;
	float radius;
public:
	inline float getCenterX() { return center_x; }
	inline float getCenterY() { return center_y; }
	inline float getRadius() { return radius; }
	Circle(float cx, float cy, float r) :Shape(), center_x(cx), center_y(cy), radius(r) {}
	void accept(Visitor* v) {
		v->visitCircle(this);
	}
};
class Rectangle :public Shape {
private:
	float x1, y1, x2, y2;
public:
	inline float getX1() { return x1; }
	inline float getY1() { return y1; }
	inline float getX2() { return x2; }
	inline float getY2() { return y2; }
	Rectangle(float x1, float y1, float x2, float y2) :x1{ x1 }, x2{ x2 }, y1{ y1 }, y2{ y2 } {}
	void accept(Visitor* v) {
		v->visitRectangle(this);
	}
};

class XmlVisitor : public Visitor {
private:
	int counter = 0;
	stringstream result;
public:
	XmlVisitor() { result << "\n<shapes>\n"; }
	string out() {
		result << "</shapes>";
		return result.str();
	}
	void visitCircle(Circle* c) override {
		cout << "N. " << ++counter;
		result << " <circle>\n\t<center>" <<
			"\n\t\t<x>" << c->getCenterX() << "</x>" <<
			"\n\t\t<y>" << c->getCenterY() << "</y>" <<
			"\n\t</center>" <<
			"\n\t<radius>" << c->getRadius() << "</radius>" <<
			"\n</circle>" << endl;
	}
	void visitRectangle(Rectangle* r) override {
		cout << "N. " << ++counter;
		result << " <rectangle>" <<
			"\n\t<x1>" << r->getX1() << "</x1>" <<
			"\n\t<y1>" << r->getY1() << "</y1>" <<
			"\n\t<x2>" << r->getX2() << "</x2>" <<
			"\n\t<y2>" << r->getY2() << "</y2>" <<
			"\n</rectangle>" << endl;
	}
};
class JsonVisitor : public Visitor {
public:
	void visitCircle(Circle* c) override {
		cout << "{" <<
			"\n\t\"center\"{" <<
			"\n\t\t\"x\":" << c->getCenterX() <<
			"\n\t\t\"y\":" << c->getCenterY() <<
			"\n\t}," <<
			"\n\t\"radius\":" << c->getRadius() <<
			"\n}" << endl;
	}
	void visitRectangle(Rectangle* r) override {
		cout << "{" <<
			"\n\t\"x1\":" << r->getX1() << "," <<
			"\n\t\"y1\":" << r->getY1() << "," <<
			"\n\t\"x2\":" << r->getX2() << "," <<
			"\n\t\"y2\":" << r->getY2() <<
			"\n}" << endl;
	}

};

class SimpleVisitor : public Visitor {
public:
	void visitCircle(Circle* c) {
		cout << "Circle(" << c->getCenterX() << ", " << c->getCenterY() << ", radius = " << c->getRadius() << ")" << endl;
	}
	void visitRectangle(Rectangle* r) {
		cout << "Rectangle(" <<
			r->getX1() << ", " <<
			r->getY1() << ", " <<
			r->getX2() << ", " <<
			r->getY2() << ") " << endl;
	}
};
int main()
{
	Circle* c = new Circle(10, 10, 20);
	Rectangle* r = new Rectangle(1, 1, 40, 50);

	vector<Shape*> shapes{ c,r };
	Visitor* v = new JsonVisitor();
	for (auto i = shapes.begin(); i != shapes.end(); i++) {
		(*i)->accept(v);
	}
	XmlVisitor* x = new XmlVisitor();
	for (auto i = shapes.begin(); i != shapes.end(); i++) {
		(*i)->accept(x);
	}
	cout << "\nrisultato della visita: " << x->out() << endl;
	v = new SimpleVisitor();
	for (auto i = shapes.begin(); i != shapes.end(); i++) {
		(*i)->accept(v);
	}
}
