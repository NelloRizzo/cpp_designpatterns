#include <iostream>
#include <list>
#include <string>

using namespace std;

class Component {
protected:
	Component* parent;
	int indent;
public:
	Component() :Component(nullptr) {}
	Component(Component* parent) : parent(parent), indent(0) {}
	inline void setParent(Component* parent) { this->parent = parent; }
	inline Component* getParent() { return parent; }
	inline void setIndent(int i) { indent = i; }
	inline int getIndent() { return indent; }

	virtual void operate() const = 0;
};

class Leaf : public Component {
public:
	void operate() const override { cout << "Leaf" << endl; }
};

class Composite : public Component {
private:
	string name;
	list<Component*> children;
public:
	Composite() :Composite("Composite") {}
	Composite(string name) : name(name) {}
	void add(Component* child) {
		children.emplace_back(child);
		child->setParent(this);
		child->setIndent(getIndent() + 1);
	}
	void remove(Component* child) {
		children.remove(child);
		child->setParent(nullptr);
	}

	void operate() const override {
		cout << "Composite " << name << endl;
		for (const Component* c : children)
		{
			for(auto i=0; i <= indent; ++i) cout << "\t";
			c->operate();
		}
	}
};

class Composite2 :public Composite {
public:
	void operate() const override {
		cout << "\n***** Composite 2 *****" << endl;
		Composite::operate();
		cout << "***********************" << endl;
	}
};

void handleComposite(Component* c) {
	c->operate();
}

int main() {
	auto leaf = new Leaf();
	handleComposite(leaf);
	auto composite = new Composite("1");
	composite->add(leaf);
	composite->add(leaf);
	auto child = new Composite("2");
	child->add(leaf);
	composite->add(child);
	composite->add(leaf);
	auto comp2 = new Composite2();
	comp2->add(leaf);
	composite->add(comp2);
	handleComposite(composite);
}