#include <iostream>
#include <ctime>
using namespace std;

class Executor {
public:
	virtual float execute() const = 0;
};
class RandomExecutor :public Executor {
public:
	RandomExecutor() { srand((unsigned)time(0)); }
	float execute() const override { return rand() % 1000; }
};

class Operator : public Executor {
private:
	Operator* parent;
public:
	Operator() :Operator(nullptr) {}
	Operator(Operator* parent) : parent(parent) {}
	inline void setParent(Operator* parent) { this->parent = parent; }
	inline Operator* getParent() const { return parent; }
};
class Operand : public Operator {
private:
	float value;
public:
	Operand() :Operand(0) {}
	Operand(float value) : value(value) {}
	float execute() const override { return value; }
};
class UnaryOperator : public Operator {
protected:
	Operator* operand;
public:
	UnaryOperator(Operator* first) : operand(first) {}
};
class ChangeSignumOperator : public UnaryOperator {
public:
	ChangeSignumOperator(Operator* op) :UnaryOperator(op) {}
	float execute() const override { return -operand->execute(); }
};
class BinaryOperator : public Operator {
protected:
	Operator* first;
	Operator* second;
public:
	BinaryOperator(Operator* first, Operator* second) : first(first), second(second) {}
};
class SumOperator : public BinaryOperator {
public:
	SumOperator(Operator* first, Operator* second) : BinaryOperator(first, second) {}
	float execute() const override { return first->execute() + second->execute(); }
};
class MinusOperator : public BinaryOperator {
public:
	MinusOperator(Operator* first, Operator* second) : BinaryOperator(first, second) {}
	float execute() const override { return first->execute() - second->execute(); }
};

void handleOperations(Executor* op) {
	cout << op->execute() << endl;
}

int main()
{
	auto uno = new Operand(1);
	auto due = new Operand(2);
	handleOperations(uno);
	auto sum = new SumOperator(uno, due);
	handleOperations(sum);
	auto sum1 = new ChangeSignumOperator(new SumOperator(due, sum));
	handleOperations(sum1);
	handleOperations(new MinusOperator(sum, new Operand(4)));
	handleOperations(new RandomExecutor());
}
