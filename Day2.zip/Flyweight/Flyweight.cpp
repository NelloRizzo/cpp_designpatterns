#include <iostream>
#include <string>
using namespace std;

struct SharedState {
	string brand;
	string model;
	string color;
public:
	SharedState(const string& brand, const string& model, const string& color) :
		brand(brand), model(model), color(color) {}

	friend ostream& operator <<(ostream& s, const SharedState& ss) {
		return s << "[" << ss.brand << "," << ss.model << "," << ss.color << "]";
	}
};

struct UniqueState
{
	string owner;
	string plate;
public:
	UniqueState(const string& owner, const string& plate) :owner(owner), plate(plate) {}
	friend ostream& operator<<(ostream& s, const UniqueState& u) {
		return s << "[" << u.owner << "," << u.plate << "]";
	}
};

class Flyweight {
private:
	SharedState* ss;
public:
	Flyweight(const SharedState* shared_state) : ss(new SharedState(*shared_state)) {}
	Flyweight(const Flyweight& other) : ss(new SharedState(*other.ss)) {}
	inline SharedState* sharedState() const { return ss; }

	void operation(const UniqueState* us) {
		cout << "Flyweight: Shared[" << *ss << "] Unique[" << *us << "]" << endl;
	}
};

class Operation {
public:
	virtual void operation() = 0;
};

void handle(Operation* o) { o->operation(); }

class MyData : public Operation {
	Flyweight* shared;
	UniqueState* unique;
public:
	MyData( Flyweight* s,  UniqueState* u) : shared(s), unique(u) {}
	void operation() override {
		shared->operation(unique);
	}
};
int main()
{
	auto s = new Flyweight(new SharedState( "Fiat", "Bravo", "Rosso" ));
	auto d1 = new MyData(s, new UniqueState("Archimede", "AX314"));
	auto d2 = new MyData(s, new UniqueState("Paperino", "313"));
	handle(d1);
	handle(d2);
}
