#include <iostream>
#include <vector>

using namespace std;

class Operation {
public:
    virtual bool canExecute(char operation) = 0;
    virtual float execute(float first, float second) = 0;
};

class ChainOfResponsability {
private :
    vector<Operation*> operations;
public:
    inline void addOperation(Operation* op) { operations.emplace_back(op); }
    inline void removeLast() { operations.pop_back(); }
    float handle(char operation, float first, float second) {
        for (auto i = operations.begin(); i != operations.end(); ++i) {
            if ((*i)->canExecute(operation))
                return (*i)->execute(first, second);
        }
        return 0;
    }
};

class AddOperation : public Operation {
public:
    bool canExecute(char c) override { return c == '+'; }
    float execute(float f, float s) { return f + s; }
};
class SubOperation : public Operation {
public:
    bool canExecute(char c) override { return c == '-'; }
    float execute(float f, float s) { return f - s; }
};
void system(ChainOfResponsability* c) {
    cout << "1 + 2 = " << c->handle('+', 1, 2)<<endl;
    cout << "1 - 2 = " << c->handle('-', 1, 2)<<endl;
}
int main()
{
    auto chain = new ChainOfResponsability();
    chain->addOperation(new AddOperation());
    chain->addOperation(new SubOperation());
    system(chain);
    chain->removeLast();
    system(chain);
}
