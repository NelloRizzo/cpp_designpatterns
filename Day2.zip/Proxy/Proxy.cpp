#include <iostream>
#include <unordered_map>
using namespace std;
class Service {
public:
	virtual long factorial(int number) {
		if (number < 2) return 1;
		return number * factorial(number - 1);
	}
};

void calculate(Service* s) {
	int n = 12;
	cout << "Calcolo del fattoriale di " << n << " = " << s->factorial(n) << endl;
}

class ServiceProxy : public Service {
	unordered_map<int, long> old;
public:
	virtual long factorial(int number) override {
		if (old.find(number) != old.end()) {
			cout << "Calcolo prelevandolo da una cache locale...\n\t";
			auto n = old[number];
			return n;
		}
		auto value = Service::factorial(number);
		old[number] = value;
		return value;
	}
};

int main()
{
	auto s = new Service();
	cout << "Uso un Service" << endl;
	calculate(s);
	calculate(s);
	calculate(s);
	auto p = new ServiceProxy();
	cout << "Uso un ServiceProxy" << endl;
	calculate(p);
	calculate(p);
	calculate(p);
}
