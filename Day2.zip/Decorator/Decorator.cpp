// Decorator.cpp : Questo file contiene la funzione 'main', in cui inizia e termina l'esecuzione del programma.
//

#include <iostream>
#include <string>

using namespace std;

class Component {
public:
	virtual string operation() const = 0;
};

class ConcreteComponent : public Component {
public:
	string operation() const override { return "ConcreteComponent"; }
};

void handleComponent(Component* c) {
	cout << c->operation() << endl;
}

class Decorator : public Component {
private:
	Component* component;
public:
	Decorator(Component* c) : component(c) {}
	string operation() const override { return component->operation(); }
};

class DecoratorA : public Decorator {
public:
	DecoratorA(Component* c) : Decorator(c) {}
	string operation() const override {
		return "DecoratorA(" + Decorator::operation() + ")";
	}
};

class DecoratorB : public Decorator {
public:
	DecoratorB(Component* c) : Decorator(c) {}
	string operation() const override {
		return "DecoratorB(" + Decorator::operation() + ")";
	}
};

class Base : public Component{};
class Rice : public Base {
public:
	string operation() const override { return "Riso"; }
};
class Spelt : public Base {
public:
	string operation() const override { return "Farro"; }
};
class Topping : public Decorator {
public:
	Topping(Component* base) : Decorator(base) {}
};
class Onion : public Topping {
public:
	Onion(Component* topping) : Topping(topping) {}
	string operation() const override { return Decorator::operation() + " + cipolla"; }
};
class Tuna : public Topping {
public:
	Tuna(Component* topping) : Topping(topping) {}
	string operation() const override { return Decorator::operation() + " + tonno"; }
};
int main()
{
	auto comp = new ConcreteComponent();
	handleComponent(comp);
	handleComponent(new DecoratorA(comp));
	handleComponent(new DecoratorB(comp));
	handleComponent(new DecoratorA(new DecoratorB(comp)));
	handleComponent(new DecoratorA(new DecoratorA(new DecoratorB(comp))));

	auto base = new Rice();
	handleComponent(new Onion(new Tuna(base)));
}