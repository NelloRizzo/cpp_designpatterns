#include <iostream>
using namespace std;

class NumberCommand {
public:
	virtual int elaborate(int number) = 0;
};

class SquareCommand :NumberCommand {
public:
	int elaborate(int n) override {
		return n * n;
	};
};

class DoubleCommand : NumberCommand {
public:
	int elaborate(int n) override { return n * 2; }
};

void system() {
	auto s = new SquareCommand();
	auto d = new DoubleCommand();

	for (auto n = 0; n < 10; ++n)
		if (n % 2 == 0)
			cout << n << '\t' << s->elaborate(n) << endl;
		else
			cout << n << '\t' << d->elaborate(n) << endl;
}
int main()
{
	system();
}
