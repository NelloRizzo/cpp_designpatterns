#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Animal {
private:
	string name;
protected:
	Animal* next;
public:
	Animal(const string& name) :Animal(name, nullptr) {}
	Animal(const string& name, Animal* next) : name(name), next(next) {}
	inline string getName() { return name; }
	virtual void eat(string food) = 0;
};
class Monkey : public Animal {
public:
	Monkey() : Monkey(nullptr) {}
	Monkey(Animal* next) : Animal("monkey", next) {}
	void eat(string food) override {
		if (food == "banana")
			cout << "I'm " << getName() << " and I'm eating " << food << endl;
		if (next) {
			cout << "I'm " << getName() << " and I don't eat " << food << endl;
			next->eat(food);
		}
	}
};
class Dog : public Animal {
public:
	Dog() : Dog(nullptr) {}
	Dog(Animal* next) : Animal("dog", next) {}
	void eat(string food) override {
		if (food == "bone")
			cout << "I'm " << getName() << " and I'm eating " << food << endl;
		if (next) {
			cout << "I'm " << getName() << " and I don't eat " << food << endl;
			next->eat(food);
		}
	}
};

class Squirrel : public Animal {
public:
	Squirrel() : Squirrel(nullptr) {}
	Squirrel(Animal* next) : Animal("squirrel", next) {}
	void eat(string food) override {
		if (food == "nut")
			cout << "I'm " << getName() << " and I'm eating " << food << endl;
		if (next) {
			cout << "I'm " << getName() << " and I don't eat " << food << endl;
			next->eat(food);
		}
	}
};
void staticSystem(vector<Animal*> a, string food) {
	for (auto i = a.begin(); i != a.end(); i++)
		if ((*i)->getName() == "dog" && food == "bone")
			(*i)->eat(food);
		else if ((*i)->getName() == "squirrel" && food == "nut")
			(*i)->eat(food);
		else if ((*i)->getName() == "monkey" && food == "banana")
			(*i)->eat(food);
		else
			cout << "No animals can eat " << food << endl;
}

void dynamicSystem(Animal* a, string food) {
	a->eat(food);
}

int main()
{
	string food = "pasta";
	vector<Animal*> a({ new Dog(), new Monkey() });
	cout << "Static system" << endl;
	staticSystem(a, food);

	auto squirrel = new Squirrel();
	auto monkey = new Monkey(squirrel);
	auto dog = new Dog(monkey);
	cout << "Dynamic system" << endl;
	dynamicSystem(dog, food);
}