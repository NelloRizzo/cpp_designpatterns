#include <iostream>
#include <string>
using namespace std;
class Command {
public:
	virtual void execute() = 0;
};

class StartCommand : public Command {
	string text;
public:
	StartCommand(string text) :Command(), text(text) {}
	void execute()override { cout << "Start " << text << endl; }
};
class EndCommand : public Command {
private:
	int result;
public:
	void setResult(int result) { this->result = result; }
	void execute()override { cout << "End - result is " << result << endl; }
};

class System {
private:
	StartCommand* onStart;
	EndCommand* onEnd;
public:
	inline void setOnStart(StartCommand* c) { onStart = c; }
	inline void setOnEnd(EndCommand* c) { onEnd = c; }

	void operate() {
		if (onStart) onStart->execute();
		cout << "working across system operations..." << endl;
		onEnd->setResult(234);
		if (onEnd) onEnd->execute();
	}
};

int main()
{
	auto my = new System();
	my->setOnStart(new StartCommand("start command"));
	my->setOnEnd(new EndCommand());
	my->operate();
}
