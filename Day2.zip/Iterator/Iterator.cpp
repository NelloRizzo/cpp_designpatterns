#include <iostream>
#include <string>
#include <vector>
using namespace std;
class DaysIterator {
public:
	virtual bool hasNext() = 0;
	virtual string next() = 0;
};

class ConcreteDaysIterator;

class DaysOfWeek {
	friend class ConcreteDaysIterator;
private:
	vector<string>days = { "Domenica", "Lunedi", "Martedi", "Mercoledi", "Giovedi", "Venerdi", "Sabato" };
	int current = 0;
public:
	inline string getDayAt(int index) { return days[index]; }
	ConcreteDaysIterator* iterator();
};

class ConcreteDaysIterator : public DaysIterator {
	DaysOfWeek* w;
	int current = 0;
public:
	ConcreteDaysIterator(DaysOfWeek* w) : w(w) {}
	bool hasNext() { return current < 7; }
	string next() { return w->days[current++]; }

};
ConcreteDaysIterator* DaysOfWeek::iterator() { return new ConcreteDaysIterator(this); }

int main()
{
	DaysOfWeek w;
	cout << "Day 1 " << w.getDayAt(1) << endl;
	ConcreteDaysIterator* i = w.iterator();
	while (i->hasNext())
		cout << i->next() << endl;
	i = w.iterator();
	while (i->hasNext())
		cout << i->next() << endl;

	vector<string>days = { "Domenica", "Lunedi", "Martedi", "Mercoledi", "Giovedi", "Venerdi", "Sabato" };
	for (auto it = days.begin(); it != days.end(); it++)
		cout << *it << endl;
}
