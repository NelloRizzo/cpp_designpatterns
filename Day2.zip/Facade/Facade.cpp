#include <iostream>
using namespace std;
class SystemA {
public:
	void operation() { cout << "Operation in SystemA" << endl; }
};
class SystemB {
public:
	void method() { cout << "Method in SystemB executing before OtherMethod in SystemB" << endl; }
	void otherMethod() { cout << "Other method in SystemB" << endl; }
};

class SystemC {
private:
	SystemA* a;
public:
	SystemC(SystemA* a) : a{ a } {}
	void execute() { cout << "Execute in SystemC" << endl; }
	void executeA() { cout << "Executing operation in SystemA > "; a->operation(); }
};

void context(SystemA* a, SystemB* b, SystemC* c) {
	a->operation();
	b->method();
	b->otherMethod();
	c->execute();
	c->executeA();
}

class Facade {
private:
	SystemA* a;
	SystemB* b;
	SystemC* c;
public:
	Facade(SystemA* a, SystemB* b) : a(a), b(b), c(new SystemC(a)) {}
	void operateA() { a->operation(); b->method(); }
	void operateB() { b->method(); b->otherMethod(); }
	void operateC() { c->execute(); c->executeA(); }
};
void context(Facade* f) {
	f->operateA();
	f->operateB();
	f->operateC();
}

int main()
{
	auto a = new SystemA();
	auto b = new SystemB();
	auto c = new SystemC(a);
	context(a, b, c);
	context(new Facade(a, b));
}
