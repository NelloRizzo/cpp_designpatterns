#include <iostream>
#include "Singleton.h"
using namespace std;
int main()
{
	auto s1 = Singleton::getInstance();
	cout << s1->getValue() << endl;
	auto s2 = Singleton::getInstance();
	s2->setValue(3);
	cout << s1->getValue() << " " << s2->getValue() << endl;
	auto s3 = Singleton::getInstance();
	s3->setValue(5);
	cout << s1->getValue() << " " << s2->getValue() << " " << s3->getValue() << endl;
}
