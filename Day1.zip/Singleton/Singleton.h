#pragma once

class Singleton {
private:
	float value;
	static Singleton* _instance;
	Singleton() : value(0) {}
public:
	static Singleton* getInstance();

	inline float getValue() const { return value; }
	inline void setValue(float value) { this->value = value; }
};

