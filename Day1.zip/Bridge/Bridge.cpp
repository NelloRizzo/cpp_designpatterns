#include <iostream>
using namespace std;

class Canvas {
public:
	virtual void drawHorizontalLine(int size) const = 0;
};

class CharCanvas : public Canvas {
public:
	void drawHorizontalLine(int size) const override {
		for (auto i = 0; i < size; ++i) {
			cout << '.';
		}
		cout << endl;
	}
};

class StringCanvas : public Canvas {
public:
	void drawHorizontalLine(int size) const override {
		cout << "Line lenght = " << size << endl;
	}
};

class DrawSystem {
private:
	Canvas* canvas;
public:
	DrawSystem(Canvas* canvas) :canvas(canvas) {}
	void drawLines(int n) const {
		for (auto i = 0; i < n; i++) {
			canvas->drawHorizontalLine((i + 1) * 5);
		}
	}
};

void drawSystem(Canvas* c) {
	auto system = new DrawSystem(c);
	system->drawLines(5);
}

int main()
{
	drawSystem(new CharCanvas());
	drawSystem(new StringCanvas());

}
