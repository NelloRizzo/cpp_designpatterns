#pragma once
#include "Food.h"
class Pasta:public Food
{
public:
	Pasta() : Food("First course", "Pasta") {}
};

