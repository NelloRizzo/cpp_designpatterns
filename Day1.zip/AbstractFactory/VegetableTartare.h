#pragma once
#include "Food.h"
class VegetableTartare:public Food
{
public:
	VegetableTartare() : Food("Appetizer", "Vegetable tartare") {}
};

