#pragma once
#include "Food.h"
class PastaWithPesto :public Food
{
public:
	PastaWithPesto() :Food("First course", "Pasta with Pesto") {}
};

