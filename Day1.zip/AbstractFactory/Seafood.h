#pragma once
#include "Food.h"

class Seafood : public Food
{
public:
	Seafood() : Food("Appetizer", "Seafood") {}
};

