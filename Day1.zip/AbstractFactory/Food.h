#pragma once

#include <iostream>
#include <string>
using namespace std;

class Food
{
private:
	string category;
	string name;
public:
	Food(string category, string name) :category(category), name(name) {}
	friend ostream& operator<<(ostream& s, const Food* f) {
		return s << f->name << " (" << f->category << ")";
	}
};
