#pragma once
class MenuMaker
{
public:
};

