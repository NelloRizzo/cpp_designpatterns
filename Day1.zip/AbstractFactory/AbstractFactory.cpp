#include <iostream>
#include "Food.h"
#include "Pasta.h"
#include "PastaWithPesto.h"
#include "Seafood.h"
#include "VegetableTartare.h"
using namespace std;

class MenuMaker {
public:
    virtual Food* createAppetizer() = 0;
    virtual Food* createFirstCourse() = 0;
};

void myMenuSystem(MenuMaker* mm) {
    cout << "Antipasto: " << mm->createAppetizer() << endl;
    cout << "Primo: " << mm->createFirstCourse() << endl;
}

class VeganMenuMaker : public MenuMaker {
public:
    Food* createAppetizer() override { return new VegetableTartare(); }
    Food* createFirstCourse() override { return new PastaWithPesto(); }
};
class HumanMenuMaker : public MenuMaker {
    Food* createAppetizer() override { return new Seafood(); }
    Food* createFirstCourse() override { return new Pasta(); }
};
int main()
{
    cout << "Menu vegano: " << endl;
    myMenuSystem(new VeganMenuMaker());
    cout << "Menu umano: " << endl;
    myMenuSystem(new HumanMenuMaker());
}
