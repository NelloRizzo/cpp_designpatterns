#include <iostream>
using namespace std;

class SystemInterface {
private:
	float v1;
	float v2;
public:
	SystemInterface() :SystemInterface(0, 0) {}
	SystemInterface(float v1, float v2) :v1(v1), v2(v2) {}
	virtual inline float getValue1() const { return v1; }
	virtual inline float getValue2() const { return v2; }
	void setValue1(float v)  { v1 = v; }
};

void calculationSystem(const SystemInterface* si) {
	// si->setValue1(10);
	cout << si->getValue1() << " + " << si->getValue2() << " = " << si->getValue1() + si->getValue2() << endl;
}

class Pair {
private:
	float first;
	float second;
public:
	Pair(float first, float second) :first(first), second(second) {}
	inline float getFirst() const { return first; }
	inline float getSecond() const { return second; }
};

class Adapter : public SystemInterface {
private:
	Pair* pair; // adaptee
public:
	Adapter(Pair* pair) : pair(pair) {}
	float getValue1() const  override { return pair->getFirst(); }
	float getValue2() const  override { return pair->getSecond(); }
};
int main()
{
	auto test = new SystemInterface(1, 2);
	auto t1 = new SystemInterface(3, 4);
	auto t2 = new SystemInterface();
	//t1.v1 = 213;
	calculationSystem(test);
	calculationSystem(t1);

	auto p = new Pair(5, 6);
	calculationSystem(new Adapter(p));
}
