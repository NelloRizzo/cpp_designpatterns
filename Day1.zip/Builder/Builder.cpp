#include <iostream>
#include <string>
using namespace std;
class Item {
private:
	string name;
public:
	Item(string name) :name(name) {}
	friend ostream& operator <<(ostream& s, const Item* i) {
		return s << i->name;
	}
};
class Walls : public Item { public: Walls() : Item("Walls") {} };
class Doors : public Item { public: Doors() : Item("Doors") {} };
class Roof : public Item { public: Roof() : Item("Roof") {} };
class Windows : public Item { public: Windows() : Item("Windows") {} };
class Garage : public Item { public: Garage() : Item("Garage") {} };
class House {
private:
	Walls* walls;
	Doors* doors;
	Windows* windows;
	Roof* roof;
	Garage* garage;	
	
	House(Walls* walls, Doors* doors, Windows* windows, Roof* roof, Garage* garage)
		:walls(walls), doors(doors), windows(windows), roof(roof), garage(garage) {}
public:
	friend ostream& operator <<(ostream& s, const House* h) {
		s << "House with: " << h->walls << ',' << h->doors << ','
			<< h->windows << ',' << h->roof;
		if (h->garage)
			s << ',' << h->garage;
		return s;
	}
	friend class HomeBuilder;
};
class HomeBuilder {
private:
	Walls* walls;
	Doors* doors;
	Windows* windows;
	Roof* roof;
	Garage* garage;

public:
	HomeBuilder* buildWalls() { walls = new Walls(); return this; }
	HomeBuilder* buildoors() { doors = new Doors(); return this; }
	HomeBuilder* builWindows() { windows = new Windows(); return this; }
	HomeBuilder* builRoof() { roof = new Roof(); return this; }
	HomeBuilder* builGarage() { garage = new Garage(); return this; }

	House* constructHome() { return new House(walls, doors, windows, roof, garage); }
};
int main()
{
	auto builder = new HomeBuilder();
	auto h = builder->buildoors()->buildWalls()->builRoof()->builWindows()->constructHome();
	cout << h << endl;
	cout << builder->builGarage()->constructHome() << endl;
}
