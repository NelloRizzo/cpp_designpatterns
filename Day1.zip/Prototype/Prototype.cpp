#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Prototype {
protected:
	string name;
	float value;
public:
	Prototype(string name) :name(name), value(0) {}
	inline void setValue(float value) { this->value = value; }

	virtual Prototype* clone() const {
		auto c = new Prototype(name);
		c->setValue(value);
		return c;
	}

	virtual string nameAsString() const { return "Prototype"; }

	friend ostream& operator<<(ostream& s, Prototype* p) {
		return s << p->nameAsString() << "(name = " << p->name << ", value = " << p->value << ")";
	}
};

class DerivedPrototype :public Prototype {
public:
	DerivedPrototype(string name) :Prototype("Derived " + name) {}

	Prototype* clone() const override {
		auto c = new DerivedPrototype(name);
		c->setValue(value);
		return c;
	}

	string nameAsString() const override { return "DerivedPrototype"; }
};

class PrototypeRegistry : Prototype {
private:
	vector<Prototype*> registry;
public:
	PrototypeRegistry(string name) :Prototype(name), registry() {}

	void add(Prototype* item) { registry.emplace_back(item); }
	Prototype* get(int index) { return registry[index]->clone(); }
};
void handlePrototype(Prototype* p) {
	auto c = p->clone();
	cout << c << endl;
}
int main()
{
	auto p = new Prototype("Sample");
	p->setValue(15);
	cout << p << endl;

	auto clone = new Prototype("Sample");
	cout << clone << endl;

	clone = p->clone();
	cout << clone << endl;

	handlePrototype(p);
	auto d = new DerivedPrototype("Sample");
	d->setValue(25);
	handlePrototype(d);

	auto reg = PrototypeRegistry("Registry");
	reg.add(p);
	reg.add(d);
	cout << "Clone del primo elemento del registro: " << reg.get(0) << endl;
	cout << "Clone del secondo elemento del registro: " << reg.get(1) << endl;
}
