#pragma once
class Calculator
{
private:
	double _accumulator;
public:
	Calculator();
	virtual void add(double number);
	virtual void sub(double number);
	virtual void div(double number);
	virtual void mul(double number);
	virtual void clear();

	inline double getAccumulator() { return _accumulator; }
};

