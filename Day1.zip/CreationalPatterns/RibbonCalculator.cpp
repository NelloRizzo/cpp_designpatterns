#include "RibbonCalculator.h"
#include <iostream>
using namespace std;

RibbonCalculator::RibbonCalculator() :Calculator() {
	cout << "Constructing RibbonCalculator" << endl;
}

void RibbonCalculator::add(double number)
{
	cout << "Adding " << number;
	Calculator::add(number);
	cout << " accumulator = " << getAccumulator() << endl;
}

void RibbonCalculator::sub(double number)
{
	cout << "Subtracting " << number;
	Calculator::sub(number);
	cout << " accumulator = " << getAccumulator() << endl;
}

void RibbonCalculator::div(double number)
{
	cout << "Dividing " << number;
	Calculator::div(number);
	cout << " accumulator = " << getAccumulator() << endl;
}

void RibbonCalculator::mul(double number)
{
	cout << "Multiplying " << number;
	Calculator::mul(number);
	cout << " accumulator = " << getAccumulator() << endl;
}

void RibbonCalculator::clear()
{
	cout << "Clearing accumulator... ";
	Calculator::clear();
	cout << " accumulator = " << getAccumulator() << endl;
}
