#include <iostream>
#include "Calculator.h"
#include "RibbonCalculator.h"

class CalculatorCreator {
public:
	virtual Calculator* factory() = 0;
};

void myCalculationSystem(Calculator* calc) {
	calc->add(10);
	calc->sub(5);
	calc->div(.5);
	calc->mul(.4);
	std::cout << "Risultato: " << calc->getAccumulator() << std::endl;
};

void myCalculationSystem(CalculatorCreator* creator) {
	Calculator* calc = creator->factory();
	calc->add(10);
	calc->sub(5);
	calc->div(.5);
	calc->mul(.4);
	std::cout << "Risultato: " << calc->getAccumulator() << std::endl;
}

class SimpleCalculatorCreator : public CalculatorCreator {
public:
	Calculator* factory() override { return new Calculator(); }
};
class RibbonCalculatorCreator : public CalculatorCreator {
public:
	Calculator* factory() override { return new RibbonCalculator(); }
};
class ComplexCalcualtorCreator : public CalculatorCreator {

	Calculator* calc = new Calculator();
	RibbonCalculator* ribbon = new RibbonCalculator();
public:	
	bool useSimple;

	ComplexCalcualtorCreator(bool useSimple) :CalculatorCreator(), useSimple(useSimple) {}
	Calculator* factory() override {
		if (useSimple) {
			calc->clear();
			return calc;
		}
		ribbon->clear();
		return ribbon;
	}
};
int main()
{
	Calculator* my = new RibbonCalculator();
	myCalculationSystem(my);

	myCalculationSystem(new SimpleCalculatorCreator());
	myCalculationSystem(new RibbonCalculatorCreator());
	auto ccc = new ComplexCalcualtorCreator(true);
	myCalculationSystem(ccc);
	ccc->useSimple = false;
	myCalculationSystem(ccc);
	ccc->useSimple = true;
	myCalculationSystem(ccc);
}