#include "Calculator.h"

Calculator::Calculator() :_accumulator(0) {}

void Calculator::add(double number) { _accumulator += number; }

void Calculator::sub(double number) { _accumulator -= number; }

void Calculator::div(double number) { _accumulator /= number; }

void Calculator::mul(double number) { _accumulator *= number; }

void Calculator::clear() { _accumulator = 0; }
