#pragma once
#include "Calculator.h"

class RibbonCalculator :
    public Calculator
{
public:
	RibbonCalculator();
	void add(double number) override;
	void sub(double number) override;
	void div(double number) override;
	void mul(double number) override;
	void clear() override;
};

